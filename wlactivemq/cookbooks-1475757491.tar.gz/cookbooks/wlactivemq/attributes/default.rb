#
#
#
#


default['activemq']['mirror']  = "http://apache.mirrors.tds.net"
default['activemq']['version'] = "5.13.4"
default['activemq']['home']  = "/opt"
default['activemq']['wrapper']['max_memory'] = "512"
default['activemq']['wrapper']['useDedicatedTaskRunner'] = "true"

default['activemq']['zooKeeper']['address'] = "localhost"
default['activemq']['zooKeeper']['hostname'] = "localhost"

override['java']['install_flavor'] = "openjdk"
override['java']['jdk_version'] = "7"
